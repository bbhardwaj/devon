define(
({
		previousMessage: "이전 선택사항",
		nextMessage: "기타 선택사항"
})
);
