define(
({
	invalidMessage: "Annettu arvo ei kelpaa.",
	missingMessage: "Tämä arvo on pakollinen.",
	rangeMessage: "Tämä arvo on sallitun alueen ulkopuolella."
})
);
