define({      
//begin v1.x content
	invalidMessage: "Uneta vrednost nije važeća.",
	missingMessage: "Ova vrednost je potrebna.",
	rangeMessage: "Ova vrednost je van opsega."
//end v1.x content
});

