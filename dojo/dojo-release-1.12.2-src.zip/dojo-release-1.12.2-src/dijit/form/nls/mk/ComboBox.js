define({      
//begin v1.x content
		previousMessage: "Претходни избори",
		nextMessage: "Повеќе избори"
//end v1.x content
});

