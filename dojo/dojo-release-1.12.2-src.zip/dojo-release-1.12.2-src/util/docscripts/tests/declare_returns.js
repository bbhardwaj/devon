define(["dojo", "dojo/declare"], function(dojo){

    return dojo.declare("foo.Bar", null, {
        // summary: FOOBAR LIVES
    })

});
